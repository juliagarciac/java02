package com.academiadev.model;

public enum DifficultyLevel {
    BEGINNER,
    INTERMEDIATE,
    ADVANCED
}
