package com.academiadev.model;

public enum CourseStatus {
    ACTIVE,
    INACTIVE
}
