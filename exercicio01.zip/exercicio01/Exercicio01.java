import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Exercicio01 {
	public static void main(String[] args) {
		List<Produto> produtos = new ArrayList<>(Arrays.asList(
			new Produto("Smartphone", 2500.00, "Eletrônicos"),
			new Produto("Notebook", 4500.00, "Eletrônicos"),
			new Produto("Livro Java", 120.00, "Livros"),
			new Produto("Headset", 350.00, "Eletrônicos"),
			new Produto("Cafeteira", 280.00, "Casa"),
			new Produto("Livro POO", 98.90, "Livros"),
			new Produto("Batedeira", 399.90, "Casa"),
			new Produto("Câmera", 1999.00, "Eletrônicos")
		));

		System.out.println("Produtos da categoria Eletrônicos (forEach + if):");
		produtos.forEach(p -> {
			if ("Eletrônicos".equals(p.getCategoria())) {
				System.out.println(p.getNome());
			}
		});

		System.out.println();
		System.out.println("Produtos da categoria Eletrônicos (stream + filter):");
		produtos.stream()
			.filter(p -> "Eletrônicos".equals(p.getCategoria()))
			.forEach(p -> System.out.println(p.getNome()));
	}
}
