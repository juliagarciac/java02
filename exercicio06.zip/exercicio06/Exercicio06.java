import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Exercicio06 {
	public static void main(String[] args) {
		List<Produto> produtos = new ArrayList<>(Arrays.asList(
			new Produto("Smartphone", 2500.00, "Eletrônicos"),
			new Produto("Notebook", 4500.00, "Eletrônicos"),
			new Produto("Livro Java", 120.00, "Livros"),
			new Produto("Headset", 350.00, "Eletrônicos")
		));

		// Usando expressão lambda
		List<String> nomesLambda = produtos.stream()
			.map(p -> p.getNome())
			.collect(Collectors.toList());
		System.out.println("Nomes (lambda): " + nomesLambda);

		// Refatorando para referência de método
		List<String> nomesMethodRef = produtos.stream()
			.map(Produto::getNome)
			.collect(Collectors.toList());
		System.out.println("Nomes (method reference): " + nomesMethodRef);
	}
}
