import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class Exercicio04 {
	public static void main(String[] args) {
		List<Produto> produtos = new ArrayList<>(Arrays.asList(
			new Produto("Smartphone", 2500.00, "Eletrônicos"),
			new Produto("Notebook", 4500.00, "Eletrônicos"),
			new Produto("Livro Java", 120.00, "Livros"),
			new Produto("Headset", 350.00, "Eletrônicos")
		));

		Optional<Produto> encontrado = buscarProdutoPorNome(produtos, "Livro Java");
		System.out.println(encontrado.map(Produto::toString).orElse("Produto não encontrado"));
	}

	public static Optional<Produto> buscarProdutoPorNome(List<Produto> produtos, String nome) {
		return produtos.stream()
			.filter(p -> p.getNome().equalsIgnoreCase(nome))
			.findFirst();
	}
}
