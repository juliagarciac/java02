 AcademiaDev - Sistema de Gestão para Academia

 O que esse sistema faz?

Basicamente, é uma plataforma completa para gerenciar:
- Alunos - cadastro, histórico, status
- Cursos - criação, edição, níveis
- Matrículas- controle de inscrições
- Pagamentos - gestão financeira
-Relatórios - dashboards e estatísticas


  Como executar (passo a passo)

 1. Pré-requisitos
- Java 17 ou superior instalado
- Maven instalado (ou usar o wrapper que vem no projeto)

 2. Baixar e extrair
- Baixe o projeto (se veio em ZIP, extraia numa pasta)
- Abra o terminal/prompt na pasta do projeto

 3. Executar
```bash
 Compilar o projeto
mvn clean compile

 Rodar o sistema
mvn spring-boot:run
```

 4. Acessar
- Abra o navegador
- Vá para: http://localhost:8080/academiadev
- Login: admin
- Senha: admin123

 O que tem na interface?

Dashboard Principal
- Estatísticas gerais (total de alunos, cursos, etc.)
- Ações rápidas
- Atividade recente

 Gestão de Alunos
- Listar, adicionar, editar alunos
- Buscar por nome, CPF, email
- Alterar status (ativo, inativo, suspenso)

 Gestão de Cursos
- Criar e gerenciar cursos
- Definir níveis (iniciante, intermediário, avançado)
- Controlar preços e duração

 Matrículas e Pagamentos
- Visualizar matrículas ativas
- Acompanhar pagamentos
- Relatórios financeiros


  Segurança

- Spring Security configurado
- Usuário padrão: admin/admin123
- CSRF habilitado




