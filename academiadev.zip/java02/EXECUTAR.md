# 🚀 AcademiaDev - Guia de Execução Rápida

## ⚡ Execução em 3 Passos

### 1. **Compilar o Projeto**
```bash
mvn clean compile
```

### 2. **Executar a Aplicação**
```bash
mvn spring-boot:run
```

### 3. **Acessar o Sistema**
- **URL Principal**: http://localhost:8080/academiadev
- **Login**: admin / admin123

## 🌟 Funcionalidades Implementadas

### ✅ **Backend Completo**
- [x] Arquitetura MVC com Spring Boot
- [x] Entidades JPA (Aluno, Curso, Matrícula, Pagamento)
- [x] Repositórios com queries customizadas
- [x] Serviços de negócio com validações
- [x] APIs REST completas
- [x] Banco H2 com dados de exemplo

### ✅ **Interface Web Profissional**
- [x] Dashboard responsivo com estatísticas
- [x] Gestão de alunos com CRUD completo
- [x] Sistema de login e segurança
- [x] Design moderno com Bootstrap 5
- [x] Ícones Font Awesome
- [x] Paleta de cores consistente

### ✅ **Recursos Avançados**
- [x] Busca e filtros em tempo real
- [x] Validações de dados
- [x] Relatórios e estatísticas
- [x] Sistema de status e enums
- [x] Relacionamentos entre entidades

## 📊 Dados de Exemplo Carregados

- **5 Alunos** com dados completos
- **4 Cursos** (Java, Python, JavaScript, DevOps)
- **5 Matrículas** ativas
- **5 Pagamentos** com diferentes status

## 🔧 Configurações

- **Porta**: 8080
- **Contexto**: /academiadev
- **Banco**: H2 in-memory
- **H2 Console**: http://localhost:8080/academiadev/h2-console

## 🎯 Próximos Passos

1. **Testar todas as funcionalidades**
2. **Personalizar dados e configurações**
3. **Implementar funcionalidades adicionais**
4. **Configurar banco de produção**

## 🆘 Solução de Problemas

### Erro de Compilação
```bash
# Verificar versão do Java
java -version

# Limpar e recompilar
mvn clean compile
```

### Erro de Porta
```bash
# Verificar se a porta 8080 está livre
netstat -an | grep 8080

# Alterar porta em application.properties
server.port=8081
```

### Erro de Banco
- Verificar se o H2 está sendo carregado
- Acessar console H2 para debug
- Verificar logs da aplicação

---

**🎉 Sistema pronto para uso! Acesse http://localhost:8080/academiadev**
