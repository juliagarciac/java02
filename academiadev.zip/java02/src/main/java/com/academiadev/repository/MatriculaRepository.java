package com.academiadev.repository;

import com.academiadev.model.Matricula;
import com.academiadev.model.StatusMatricula;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface MatriculaRepository extends JpaRepository<Matricula, Long> {
    
    List<Matricula> findByAlunoId(Long alunoId);
    
    List<Matricula> findByCursoId(Long cursoId);
    
    List<Matricula> findByStatus(StatusMatricula status);
    
    List<Matricula> findByDataInicioBetween(LocalDate dataInicio, LocalDate dataFim);
    
    @Query("SELECT m FROM Matricula m WHERE m.status = 'ATIVA' AND m.dataTermino < :dataAtual")
    List<Matricula> findMatriculasVencidas(@Param("dataAtual") LocalDate dataAtual);
    
    @Query("SELECT m FROM Matricula m WHERE m.status = 'ATIVA' AND :dataAtual BETWEEN m.dataInicio AND m.dataTermino")
    List<Matricula> findMatriculasVigentes(@Param("dataAtual") LocalDate dataAtual);
    
    @Query("SELECT COUNT(m) FROM Matricula m WHERE m.status = :status")
    Long countByStatus(@Param("status") StatusMatricula status);
    
    @Query("SELECT m FROM Matricula m WHERE m.aluno.id = :alunoId AND m.status = 'ATIVA'")
    List<Matricula> findMatriculasAtivasPorAluno(@Param("alunoId") Long alunoId);
    
    @Query("SELECT m FROM Matricula m WHERE m.curso.id = :cursoId AND m.status = 'ATIVA'")
    List<Matricula> findMatriculasAtivasPorCurso(@Param("cursoId") Long cursoId);
    
    boolean existsByAlunoIdAndCursoIdAndStatus(Long alunoId, Long cursoId, StatusMatricula status);
}
