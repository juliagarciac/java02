package com.academiadev.repository;

import com.academiadev.model.Curso;
import com.academiadev.model.NivelCurso;
import com.academiadev.model.StatusCurso;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface CursoRepository extends JpaRepository<Curso, Long> {
    
    List<Curso> findByStatus(StatusCurso status);
    
    List<Curso> findByNivel(NivelCurso nivel);
    
    List<Curso> findByPrecoBetween(BigDecimal precoMin, BigDecimal precoMax);
    
    List<Curso> findByNomeContainingIgnoreCase(String nome);
    
    @Query("SELECT c FROM Curso c WHERE c.status = 'ATIVO' ORDER BY c.nome")
    List<Curso> findCursosAtivos();
    
    @Query("SELECT c FROM Curso c WHERE c.preco <= :precoMax AND c.status = 'ATIVO'")
    List<Curso> findCursosAtivosPorPrecoMaximo(@Param("precoMax") BigDecimal precoMax);
    
    @Query("SELECT c FROM Curso c JOIN c.matriculas m GROUP BY c ORDER BY COUNT(m) DESC")
    List<Curso> findCursosMaisPopulares();
    
    @Query("SELECT COUNT(c) FROM Curso c WHERE c.status = :status")
    Long countByStatus(@Param("status") StatusCurso status);
    
    boolean existsByNome(String nome);
}
