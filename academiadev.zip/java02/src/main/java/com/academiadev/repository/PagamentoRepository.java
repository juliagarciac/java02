package com.academiadev.repository;

import com.academiadev.model.Pagamento;
import com.academiadev.model.StatusPagamento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface PagamentoRepository extends JpaRepository<Pagamento, Long> {
    
    List<Pagamento> findByAlunoId(Long alunoId);
    
    List<Pagamento> findByStatus(StatusPagamento status);
    
    List<Pagamento> findByDataVencimentoBetween(LocalDate dataInicio, LocalDate dataFim);
    
    List<Pagamento> findByDataVencimentoBeforeAndStatus(LocalDate data, StatusPagamento status);
    
    @Query("SELECT p FROM Pagamento p WHERE p.status = 'PENDENTE' AND p.dataVencimento < :dataAtual")
    List<Pagamento> findPagamentosVencidos(@Param("dataAtual") LocalDate dataAtual);
    
    @Query("SELECT p FROM Pagamento p WHERE p.status = 'PENDENTE' AND p.dataVencimento BETWEEN :dataInicio AND :dataFim")
    List<Pagamento> findPagamentosPendentesPorPeriodo(@Param("dataInicio") LocalDate dataInicio, 
                                                      @Param("dataFim") LocalDate dataFim);
    
    @Query("SELECT SUM(p.valor) FROM Pagamento p WHERE p.status = 'PAGO' AND p.dataPagamento BETWEEN :dataInicio AND :dataFim")
    BigDecimal calcularReceitaPorPeriodo(@Param("dataInicio") LocalDate dataInicio, 
                                        @Param("dataFim") LocalDate dataFim);
    
    @Query("SELECT COUNT(p) FROM Pagamento p WHERE p.status = :status")
    Long countByStatus(@Param("status") StatusPagamento status);
    
    @Query("SELECT p FROM Pagamento p WHERE p.aluno.id = :alunoId AND p.status = 'PENDENTE' ORDER BY p.dataVencimento")
    List<Pagamento> findPagamentosPendentesPorAluno(@Param("alunoId") Long alunoId);
    
    @Query("SELECT p FROM Pagamento p WHERE p.valor >= :valorMin AND p.status = 'PENDENTE'")
    List<Pagamento> findPagamentosPendentesPorValorMinimo(@Param("valorMin") BigDecimal valorMin);
}
