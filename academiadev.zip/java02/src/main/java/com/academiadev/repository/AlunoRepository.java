package com.academiadev.repository;

import com.academiadev.model.Aluno;
import com.academiadev.model.StatusAluno;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AlunoRepository extends JpaRepository<Aluno, Long> {
    
    Optional<Aluno> findByCpf(String cpf);
    
    Optional<Aluno> findByEmail(String email);
    
    List<Aluno> findByStatus(StatusAluno status);
    
    List<Aluno> findByNomeContainingIgnoreCase(String nome);
    
    @Query("SELECT a FROM Aluno a WHERE a.nome LIKE %:termo% OR a.email LIKE %:termo% OR a.cpf LIKE %:termo%")
    List<Aluno> buscarPorTermo(@Param("termo") String termo);
    
    @Query("SELECT COUNT(a) FROM Aluno a WHERE a.status = :status")
    Long countByStatus(@Param("status") StatusAluno status);
    
    @Query("SELECT a FROM Aluno a JOIN a.matriculas m WHERE m.status = 'ATIVA'")
    List<Aluno> findAlunosComMatriculasAtivas();
    
    boolean existsByCpf(String cpf);
    
    boolean existsByEmail(String email);
}
