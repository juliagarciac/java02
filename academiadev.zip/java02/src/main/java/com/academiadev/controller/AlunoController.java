package com.academiadev.controller;

import com.academiadev.model.Aluno;
import com.academiadev.model.StatusAluno;
import com.academiadev.service.AlunoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/alunos")
@CrossOrigin(origins = "*")
public class AlunoController {
    
    @Autowired
    private AlunoService alunoService;
    
    @GetMapping
    public ResponseEntity<List<Aluno>> listarTodos() {
        List<Aluno> alunos = alunoService.listarTodos();
        return ResponseEntity.ok(alunos);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Aluno> buscarPorId(@PathVariable Long id) {
        Optional<Aluno> aluno = alunoService.buscarPorId(id);
        return aluno.map(ResponseEntity::ok)
                   .orElse(ResponseEntity.notFound().build());
    }
    
    @GetMapping("/cpf/{cpf}")
    public ResponseEntity<Aluno> buscarPorCpf(@PathVariable String cpf) {
        Optional<Aluno> aluno = alunoService.buscarPorCpf(cpf);
        return aluno.map(ResponseEntity::ok)
                   .orElse(ResponseEntity.notFound().build());
    }
    
    @GetMapping("/email/{email}")
    public ResponseEntity<Aluno> buscarPorEmail(@PathVariable String email) {
        Optional<Aluno> aluno = alunoService.buscarPorEmail(email);
        return aluno.map(ResponseEntity::ok)
                   .orElse(ResponseEntity.notFound().build());
    }
    
    @GetMapping("/busca")
    public ResponseEntity<List<Aluno>> buscarPorTermo(@RequestParam String termo) {
        List<Aluno> alunos = alunoService.buscarPorTermo(termo);
        return ResponseEntity.ok(alunos);
    }
    
    @GetMapping("/status/{status}")
    public ResponseEntity<List<Aluno>> buscarPorStatus(@PathVariable StatusAluno status) {
        List<Aluno> alunos = alunoService.buscarPorStatus(status);
        return ResponseEntity.ok(alunos);
    }
    
    @GetMapping("/ativos")
    public ResponseEntity<List<Aluno>> buscarAlunosAtivos() {
        List<Aluno> alunos = alunoService.buscarAlunosAtivos();
        return ResponseEntity.ok(alunos);
    }
    
    @GetMapping("/matriculas-ativas")
    public ResponseEntity<List<Aluno>> buscarAlunosComMatriculasAtivas() {
        List<Aluno> alunos = alunoService.buscarAlunosComMatriculasAtivas();
        return ResponseEntity.ok(alunos);
    }
    
    @PostMapping
    public ResponseEntity<Aluno> criar(@Valid @RequestBody Aluno aluno) {
        try {
            Aluno alunoSalvo = alunoService.salvar(aluno);
            return ResponseEntity.status(HttpStatus.CREATED).body(alunoSalvo);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Aluno> atualizar(@PathVariable Long id, @Valid @RequestBody Aluno aluno) {
        try {
            if (!alunoService.buscarPorId(id).isPresent()) {
                return ResponseEntity.notFound().build();
            }
            aluno.setId(id);
            Aluno alunoAtualizado = alunoService.salvar(aluno);
            return ResponseEntity.ok(alunoAtualizado);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        try {
            alunoService.deletar(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    @PatchMapping("/{id}/status")
    public ResponseEntity<Aluno> atualizarStatus(@PathVariable Long id, @RequestParam StatusAluno status) {
        try {
            Aluno aluno = alunoService.atualizarStatus(id, status);
            return ResponseEntity.ok(aluno);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @GetMapping("/estatisticas/total")
    public ResponseEntity<Long> contarTotalAlunos() {
        long total = alunoService.contarTotalAlunos();
        return ResponseEntity.ok(total);
    }
    
    @GetMapping("/estatisticas/ativos")
    public ResponseEntity<Long> contarAlunosAtivos() {
        long ativos = alunoService.contarAlunosAtivos();
        return ResponseEntity.ok(ativos);
    }
    
    @GetMapping("/estatisticas/idade")
    public ResponseEntity<List<Aluno>> buscarPorIdade(
            @RequestParam int idadeMin, @RequestParam int idadeMax) {
        List<Aluno> alunos = alunoService.buscarAlunosPorIdade(idadeMin, idadeMax);
        return ResponseEntity.ok(alunos);
    }
}
