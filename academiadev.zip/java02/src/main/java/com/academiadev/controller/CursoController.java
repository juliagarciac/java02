package com.academiadev.controller;

import com.academiadev.model.Curso;
import com.academiadev.model.NivelCurso;
import com.academiadev.model.StatusCurso;
import com.academiadev.service.CursoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/cursos")
@CrossOrigin(origins = "*")
public class CursoController {
    
    @Autowired
    private CursoService cursoService;
    
    @GetMapping
    public ResponseEntity<List<Curso>> listarTodos() {
        List<Curso> cursos = cursoService.listarTodos();
        return ResponseEntity.ok(cursos);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Curso> buscarPorId(@PathVariable Long id) {
        Optional<Curso> curso = cursoService.buscarPorId(id);
        return curso.map(ResponseEntity::ok)
                   .orElse(ResponseEntity.notFound().build());
    }
    
    @GetMapping("/ativos")
    public ResponseEntity<List<Curso>> buscarCursosAtivos() {
        List<Curso> cursos = cursoService.buscarCursosAtivos();
        return ResponseEntity.ok(cursos);
    }
    
    @GetMapping("/nivel/{nivel}")
    public ResponseEntity<List<Curso>> buscarPorNivel(@PathVariable NivelCurso nivel) {
        List<Curso> cursos = cursoService.buscarPorNivel(nivel);
        return ResponseEntity.ok(cursos);
    }
    
    @GetMapping("/status/{status}")
    public ResponseEntity<List<Curso>> buscarPorStatus(@PathVariable StatusCurso status) {
        List<Curso> cursos = cursoService.buscarPorStatus(status);
        return ResponseEntity.ok(cursos);
    }
    
    @GetMapping("/preco-maximo")
    public ResponseEntity<List<Curso>> buscarPorPrecoMaximo(@RequestParam BigDecimal precoMax) {
        List<Curso> cursos = cursoService.buscarPorPrecoMaximo(precoMax);
        return ResponseEntity.ok(cursos);
    }
    
    @GetMapping("/busca")
    public ResponseEntity<List<Curso>> buscarPorNome(@RequestParam String nome) {
        List<Curso> cursos = cursoService.buscarPorNome(nome);
        return ResponseEntity.ok(cursos);
    }
    
    @GetMapping("/populares")
    public ResponseEntity<List<Curso>> buscarCursosMaisPopulares() {
        List<Curso> cursos = cursoService.buscarCursosMaisPopulares();
        return ResponseEntity.ok(cursos);
    }
    
    @GetMapping("/faixa-preco")
    public ResponseEntity<List<Curso>> buscarPorFaixaPreco(
            @RequestParam BigDecimal precoMin, @RequestParam BigDecimal precoMax) {
        List<Curso> cursos = cursoService.buscarCursosPorFaixaPreco(precoMin, precoMax);
        return ResponseEntity.ok(cursos);
    }
    
    @PostMapping
    public ResponseEntity<Curso> criar(@Valid @RequestBody Curso curso) {
        try {
            Curso cursoSalvo = cursoService.salvar(curso);
            return ResponseEntity.status(HttpStatus.CREATED).body(cursoSalvo);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Curso> atualizar(@PathVariable Long id, @Valid @RequestBody Curso curso) {
        try {
            if (!cursoService.buscarPorId(id).isPresent()) {
                return ResponseEntity.notFound().build();
            }
            curso.setId(id);
            Curso cursoAtualizado = cursoService.salvar(curso);
            return ResponseEntity.ok(cursoAtualizado);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        try {
            cursoService.deletar(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().build();
        }
    }
    
    @PatchMapping("/{id}/status")
    public ResponseEntity<Curso> atualizarStatus(@PathVariable Long id, @RequestParam StatusCurso status) {
        try {
            Curso curso = cursoService.atualizarStatus(id, status);
            return ResponseEntity.ok(curso);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @GetMapping("/estatisticas/total")
    public ResponseEntity<Long> contarTotalCursos() {
        long total = cursoService.contarTotalCursos();
        return ResponseEntity.ok(total);
    }
    
    @GetMapping("/estatisticas/ativos")
    public ResponseEntity<Long> contarCursosAtivos() {
        long ativos = cursoService.contarCursosAtivos();
        return ResponseEntity.ok(ativos);
    }
    
    @GetMapping("/estatisticas/receita-total")
    public ResponseEntity<BigDecimal> calcularReceitaTotal() {
        BigDecimal receita = cursoService.calcularReceitaTotal();
        return ResponseEntity.ok(receita);
    }
}
