package com.academiadev.controller;

import com.academiadev.service.AlunoService;
import com.academiadev.service.CursoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class WebController {
    
    @Autowired
    private AlunoService alunoService;
    
    @Autowired
    private CursoService cursoService;
    
    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("totalAlunos", alunoService.contarTotalAlunos());
        model.addAttribute("alunosAtivos", alunoService.contarAlunosAtivos());
        model.addAttribute("totalCursos", cursoService.contarTotalCursos());
        model.addAttribute("cursosAtivos", cursoService.contarCursosAtivos());
        return "index";
    }
    
    @GetMapping("/login")
    public String login() {
        return "login";
    }
    
    @GetMapping("/alunos")
    public String alunos(Model model) {
        model.addAttribute("alunos", alunoService.listarTodos());
        return "alunos";
    }
    
    @GetMapping("/cursos")
    public String cursos(Model model) {
        model.addAttribute("cursos", cursoService.listarTodos());
        return "cursos";
    }
    
    @GetMapping("/matriculas")
    public String matriculas() {
        return "matriculas";
    }
    
    @GetMapping("/pagamentos")
    public String pagamentos() {
        return "pagamentos";
    }
    
    @GetMapping("/relatorios")
    public String relatorios() {
        return "relatorios";
    }
    
    @GetMapping("/configuracoes")
    public String configuracoes() {
        return "configuracoes";
    }
}
