package com.academiadev.model;

public enum StatusMatricula {
    ATIVA("Ativa"),
    CONCLUIDA("Concluída"),
    CANCELADA("Cancelada"),
    SUSPENSA("Suspensa");
    
    private final String descricao;
    
    StatusMatricula(String descricao) {
        this.descricao = descricao;
    }
    
    public String getDescricao() {
        return descricao;
    }
    
    @Override
    public String toString() {
        return descricao;
    }
}
