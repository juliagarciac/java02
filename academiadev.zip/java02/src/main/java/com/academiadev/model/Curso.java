package com.academiadev.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "cursos")
public class Curso {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @NotBlank(message = "Nome do curso é obrigatório")
    @Column(nullable = false, unique = true)
    private String nome;
    
    @Column(columnDefinition = "TEXT")
    private String descricao;
    
    @NotNull(message = "Preço é obrigatório")
    @Positive(message = "Preço deve ser positivo")
    private BigDecimal preco;
    
    @NotNull(message = "Duração é obrigatória")
    @Positive(message = "Duração deve ser positiva")
    private Integer duracaoMeses;
    
    @Enumerated(EnumType.STRING)
    @NotNull(message = "Nível é obrigatório")
    private NivelCurso nivel;
    
    @Enumerated(EnumType.STRING)
    @NotNull(message = "Status é obrigatório")
    private StatusCurso status = StatusCurso.ATIVO;
    
    @OneToMany(mappedBy = "curso", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Matricula> matriculas = new ArrayList<>();
    
    // Constructors
    public Curso() {}
    
    public Curso(String nome, String descricao, BigDecimal preco, 
                 Integer duracaoMeses, NivelCurso nivel) {
        this.nome = nome;
        this.descricao = descricao;
        this.preco = preco;
        this.duracaoMeses = duracaoMeses;
        this.nivel = nivel;
    }
    
    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    
    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }
    
    public BigDecimal getPreco() { return preco; }
    public void setPreco(BigDecimal preco) { this.preco = preco; }
    
    public Integer getDuracaoMeses() { return duracaoMeses; }
    public void setDuracaoMeses(Integer duracaoMeses) { this.duracaoMeses = duracaoMeses; }
    
    public NivelCurso getNivel() { return nivel; }
    public void setNivel(NivelCurso nivel) { this.nivel = nivel; }
    
    public StatusCurso getStatus() { return status; }
    public void setStatus(StatusCurso status) { this.status = status; }
    
    public List<Matricula> getMatriculas() { return matriculas; }
    public void setMatriculas(List<Matricula> matriculas) { this.matriculas = matriculas; }
    
    // Business Methods
    public void adicionarMatricula(Matricula matricula) {
        this.matriculas.add(matricula);
        matricula.setCurso(this);
    }
    
    public boolean isAtivo() {
        return StatusCurso.ATIVO.equals(this.status);
    }
    
    public int getTotalAlunos() {
        return this.matriculas.size();
    }
    
    @Override
    public String toString() {
        return "Curso{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", preco=" + preco +
                ", nivel=" + nivel +
                ", status=" + status +
                '}';
    }
}
