package com.academiadev.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "matriculas")
public class Matricula {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "aluno_id", nullable = false)
    @NotNull(message = "Aluno é obrigatório")
    private Aluno aluno;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "curso_id", nullable = false)
    @NotNull(message = "Curso é obrigatório")
    private Curso curso;
    
    @NotNull(message = "Data de matrícula é obrigatória")
    private LocalDate dataMatricula;
    
    @NotNull(message = "Data de início é obrigatória")
    private LocalDate dataInicio;
    
    @NotNull(message = "Data de término é obrigatória")
    private LocalDate dataTermino;
    
    @Enumerated(EnumType.STRING)
    @NotNull(message = "Status da matrícula é obrigatório")
    private StatusMatricula status = StatusMatricula.ATIVA;
    
    private LocalDateTime dataCriacao;
    
    private LocalDateTime dataAtualizacao;
    
    @PrePersist
    protected void onCreate() {
        dataCriacao = LocalDateTime.now();
        dataAtualizacao = LocalDateTime.now();
    }
    
    @PreUpdate
    protected void onUpdate() {
        dataAtualizacao = LocalDateTime.now();
    }
    
    // Constructors
    public Matricula() {}
    
    public Matricula(Aluno aluno, Curso curso, LocalDate dataInicio, LocalDate dataTermino) {
        this.aluno = aluno;
        this.curso = curso;
        this.dataMatricula = LocalDate.now();
        this.dataInicio = dataInicio;
        this.dataTermino = dataTermino;
    }
    
    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    
    public Aluno getAluno() { return aluno; }
    public void setAluno(Aluno aluno) { this.aluno = aluno; }
    
    public Curso getCurso() { return curso; }
    public void setCurso(Curso curso) { this.curso = curso; }
    
    public LocalDate getDataMatricula() { return dataMatricula; }
    public void setDataMatricula(LocalDate dataMatricula) { this.dataMatricula = dataMatricula; }
    
    public LocalDate getDataInicio() { return dataInicio; }
    public void setDataInicio(LocalDate dataInicio) { this.dataInicio = dataInicio; }
    
    public LocalDate getDataTermino() { return dataTermino; }
    public void setDataTermino(LocalDate dataTermino) { this.dataTermino = dataTermino; }
    
    public StatusMatricula getStatus() { return status; }
    public void setStatus(StatusMatricula status) { this.status = status; }
    
    public LocalDateTime getDataCriacao() { return dataCriacao; }
    public void setDataCriacao(LocalDateTime dataCriacao) { this.dataCriacao = dataCriacao; }
    
    public LocalDateTime getDataAtualizacao() { return dataAtualizacao; }
    public void setDataAtualizacao(LocalDateTime dataAtualizacao) { this.dataAtualizacao = dataAtualizacao; }
    
    // Business Methods
    public boolean isAtiva() {
        return StatusMatricula.ATIVA.equals(this.status);
    }
    
    public boolean isVencida() {
        return LocalDate.now().isAfter(this.dataTermino);
    }
    
    public boolean isVigente() {
        LocalDate hoje = LocalDate.now();
        return hoje.isAfter(this.dataInicio) && hoje.isBefore(this.dataTermino);
    }
    
    @Override
    public String toString() {
        return "Matricula{" +
                "id=" + id +
                ", aluno=" + (aluno != null ? aluno.getNome() : "null") +
                ", curso=" + (curso != null ? curso.getNome() : "null") +
                ", status=" + status +
                '}';
    }
}
