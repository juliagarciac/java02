package com.academiadev.model;

public enum NivelCurso {
    INICIANTE("Iniciante"),
    INTERMEDIARIO("Intermediário"),
    AVANCADO("Avançado"),
    EXPERT("Expert");
    
    private final String descricao;
    
    NivelCurso(String descricao) {
        this.descricao = descricao;
    }
    
    public String getDescricao() {
        return descricao;
    }
    
    @Override
    public String toString() {
        return descricao;
    }
}
