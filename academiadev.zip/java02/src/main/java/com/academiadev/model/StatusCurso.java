package com.academiadev.model;

public enum StatusCurso {
    ATIVO("Ativo"),
    INATIVO("Inativo"),
    EM_BREVE("Em Breve"),
    ENCERRADO("Encerrado");
    
    private final String descricao;
    
    StatusCurso(String descricao) {
        this.descricao = descricao;
    }
    
    public String getDescricao() {
        return descricao;
    }
    
    @Override
    public String toString() {
        return descricao;
    }
}
