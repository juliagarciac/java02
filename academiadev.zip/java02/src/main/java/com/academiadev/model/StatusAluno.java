package com.academiadev.model;

public enum StatusAluno {
    ATIVO("Ativo"),
    INATIVO("Inativo"),
    SUSPENSO("Suspenso"),
    CANCELADO("Cancelado");
    
    private final String descricao;
    
    StatusAluno(String descricao) {
        this.descricao = descricao;
    }
    
    public String getDescricao() {
        return descricao;
    }
    
    @Override
    public String toString() {
        return descricao;
    }
}
