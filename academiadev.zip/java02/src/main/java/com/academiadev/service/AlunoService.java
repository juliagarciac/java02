package com.academiadev.service;

import com.academiadev.model.Aluno;
import com.academiadev.model.StatusAluno;
import com.academiadev.repository.AlunoRepository;
import com.academiadev.repository.MatriculaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class AlunoService {
    
    @Autowired
    private AlunoRepository alunoRepository;
    
    @Autowired
    private MatriculaRepository matriculaRepository;
    
    public List<Aluno> listarTodos() {
        return alunoRepository.findAll();
    }
    
    public Optional<Aluno> buscarPorId(Long id) {
        return alunoRepository.findById(id);
    }
    
    public Optional<Aluno> buscarPorCpf(String cpf) {
        return alunoRepository.findByCpf(cpf);
    }
    
    public Optional<Aluno> buscarPorEmail(String email) {
        return alunoRepository.findByEmail(email);
    }
    
    public List<Aluno> buscarPorTermo(String termo) {
        return alunoRepository.buscarPorTermo(termo);
    }
    
    public List<Aluno> buscarPorStatus(StatusAluno status) {
        return alunoRepository.findByStatus(status);
    }
    
    public List<Aluno> buscarAlunosAtivos() {
        return alunoRepository.findByStatus(StatusAluno.ATIVO);
    }
    
    public List<Aluno> buscarAlunosComMatriculasAtivas() {
        return alunoRepository.findAlunosComMatriculasAtivas();
    }
    
    public Aluno salvar(Aluno aluno) {
        // Validações de negócio
        if (aluno.getId() == null) {
            // Novo aluno
            if (alunoRepository.existsByCpf(aluno.getCpf())) {
                throw new RuntimeException("CPF já cadastrado: " + aluno.getCpf());
            }
            if (alunoRepository.existsByEmail(aluno.getEmail())) {
                throw new RuntimeException("Email já cadastrado: " + aluno.getEmail());
            }
        }
        
        return alunoRepository.save(aluno);
    }
    
    public void deletar(Long id) {
        Aluno aluno = alunoRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Aluno não encontrado com ID: " + id));
        
        // Verificar se tem matrículas ativas
        long matriculasAtivas = matriculaRepository.countByStatus(
            com.academiadev.model.StatusMatricula.ATIVA);
        
        if (matriculasAtivas > 0) {
            throw new RuntimeException("Não é possível deletar aluno com matrículas ativas");
        }
        
        alunoRepository.deleteById(id);
    }
    
    public Aluno atualizarStatus(Long id, StatusAluno novoStatus) {
        Aluno aluno = alunoRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Aluno não encontrado com ID: " + id));
        
        aluno.setStatus(novoStatus);
        return alunoRepository.save(aluno);
    }
    
    public long contarAlunosAtivos() {
        return alunoRepository.countByStatus(StatusAluno.ATIVO);
    }
    
    public long contarTotalAlunos() {
        return alunoRepository.count();
    }
    
    public List<Aluno> buscarAlunosPorIdade(int idadeMin, int idadeMax) {
        LocalDate dataMaxima = LocalDate.now().minusYears(idadeMin);
        LocalDate dataMinima = LocalDate.now().minusYears(idadeMax + 1);
        
        return alunoRepository.findAll().stream()
            .filter(aluno -> {
                if (aluno.getDataNascimento() == null) return false;
                return aluno.getDataNascimento().isAfter(dataMinima) && 
                       aluno.getDataNascimento().isBefore(dataMaxima);
            })
            .toList();
    }
}
