package com.academiadev.service;

import com.academiadev.model.Curso;
import com.academiadev.model.NivelCurso;
import com.academiadev.model.StatusCurso;
import com.academiadev.repository.CursoRepository;
import com.academiadev.repository.MatriculaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class CursoService {
    
    @Autowired
    private CursoRepository cursoRepository;
    
    @Autowired
    private MatriculaRepository matriculaRepository;
    
    public List<Curso> listarTodos() {
        return cursoRepository.findAll();
    }
    
    public Optional<Curso> buscarPorId(Long id) {
        return cursoRepository.findById(id);
    }
    
    public List<Curso> buscarCursosAtivos() {
        return cursoRepository.findCursosAtivos();
    }
    
    public List<Curso> buscarPorNivel(NivelCurso nivel) {
        return cursoRepository.findByNivel(nivel);
    }
    
    public List<Curso> buscarPorStatus(StatusCurso status) {
        return cursoRepository.findByStatus(status);
    }
    
    public List<Curso> buscarPorPrecoMaximo(BigDecimal precoMax) {
        return cursoRepository.findCursosAtivosPorPrecoMaximo(precoMax);
    }
    
    public List<Curso> buscarPorNome(String nome) {
        return cursoRepository.findByNomeContainingIgnoreCase(nome);
    }
    
    public List<Curso> buscarCursosMaisPopulares() {
        return cursoRepository.findCursosMaisPopulares();
    }
    
    public Curso salvar(Curso curso) {
        // Validações de negócio
        if (curso.getId() == null) {
            // Novo curso
            if (cursoRepository.existsByNome(curso.getNome())) {
                throw new RuntimeException("Curso com este nome já existe: " + curso.getNome());
            }
        }
        
        if (curso.getPreco().compareTo(BigDecimal.ZERO) <= 0) {
            throw new RuntimeException("Preço do curso deve ser maior que zero");
        }
        
        if (curso.getDuracaoMeses() <= 0) {
            throw new RuntimeException("Duração do curso deve ser maior que zero");
        }
        
        return cursoRepository.save(curso);
    }
    
    public void deletar(Long id) {
        Curso curso = cursoRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Curso não encontrado com ID: " + id));
        
        // Verificar se tem matrículas ativas
        long matriculasAtivas = matriculaRepository.countByStatus(
            com.academiadev.model.StatusMatricula.ATIVA);
        
        if (matriculasAtivas > 0) {
            throw new RuntimeException("Não é possível deletar curso com matrículas ativas");
        }
        
        cursoRepository.deleteById(id);
    }
    
    public Curso atualizarStatus(Long id, StatusCurso novoStatus) {
        Curso curso = cursoRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Curso não encontrado com ID: " + id));
        
        curso.setStatus(novoStatus);
        return cursoRepository.save(curso);
    }
    
    public long contarCursosAtivos() {
        return cursoRepository.countByStatus(StatusCurso.ATIVO);
    }
    
    public long contarTotalCursos() {
        return cursoRepository.count();
    }
    
    public BigDecimal calcularReceitaTotal() {
        return cursoRepository.findAll().stream()
            .filter(Curso::isAtivo)
            .map(curso -> curso.getPreco().multiply(BigDecimal.valueOf(curso.getTotalAlunos())))
            .reduce(BigDecimal.ZERO, BigDecimal::add);
    }
    
    public List<Curso> buscarCursosPorFaixaPreco(BigDecimal precoMin, BigDecimal precoMax) {
        return cursoRepository.findByPrecoBetween(precoMin, precoMax);
    }
    
    public Curso buscarPorNomeExato(String nome) {
        return cursoRepository.findAll().stream()
            .filter(curso -> curso.getNome().equalsIgnoreCase(nome))
            .findFirst()
            .orElse(null);
    }
}
