package com.academiadev.config;

import com.academiadev.model.*;
import com.academiadev.repository.AlunoRepository;
import com.academiadev.repository.CursoRepository;
import com.academiadev.repository.MatriculaRepository;
import com.academiadev.repository.PagamentoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Arrays;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private AlunoRepository alunoRepository;

    @Autowired
    private CursoRepository cursoRepository;

    @Autowired
    private MatriculaRepository matriculaRepository;

    @Autowired
    private PagamentoRepository pagamentoRepository;

    @Override
    public void run(String... args) throws Exception {
        // Limpar dados existentes
        pagamentoRepository.deleteAll();
        matriculaRepository.deleteAll();
        alunoRepository.deleteAll();
        cursoRepository.deleteAll();

        // Criar cursos
        Curso cursoJava = new Curso(
            "Java Básico ao Avançado",
            "Curso completo de Java com foco em POO, Spring Boot e desenvolvimento web",
            new BigDecimal("2999.90"),
            6,
            NivelCurso.INTERMEDIARIO
        );
        cursoJava = cursoRepository.save(cursoJava);

        Curso cursoPython = new Curso(
            "Python para Data Science",
            "Aprenda Python do zero e suas principais bibliotecas para análise de dados",
            new BigDecimal("2499.90"),
            4,
            NivelCurso.INICIANTE
        );
        cursoPython = cursoRepository.save(cursoPython);

        Curso cursoJavaScript = new Curso(
            "JavaScript Full Stack",
            "Desenvolvimento completo com JavaScript, Node.js, React e MongoDB",
            new BigDecimal("3499.90"),
            8,
            NivelCurso.AVANCADO
        );
        cursoJavaScript = cursoRepository.save(cursoJavaScript);

        Curso cursoDevOps = new Curso(
            "DevOps e Cloud Computing",
            "Infraestrutura como código, Docker, Kubernetes e AWS",
            new BigDecimal("3999.90"),
            5,
            NivelCurso.EXPERT
        );
        cursoDevOps = cursoRepository.save(cursoDevOps);

        // Criar alunos
        Aluno aluno1 = new Aluno(
            "João Silva Santos",
            "123.456.789-00",
            "joao.silva@email.com",
            "(11) 99999-1111",
            LocalDate.of(1995, 3, 15),
            "Rua das Flores, 123 - São Paulo/SP"
        );
        aluno1 = alunoRepository.save(aluno1);

        Aluno aluno2 = new Aluno(
            "Maria Oliveira Costa",
            "987.654.321-00",
            "maria.oliveira@email.com",
            "(11) 88888-2222",
            LocalDate.of(1992, 7, 22),
            "Av. Paulista, 1000 - São Paulo/SP"
        );
        aluno2 = alunoRepository.save(aluno2);

        Aluno aluno3 = new Aluno(
            "Pedro Almeida Lima",
            "456.789.123-00",
            "pedro.almeida@email.com",
            "(11) 77777-3333",
            LocalDate.of(1998, 11, 8),
            "Rua Augusta, 500 - São Paulo/SP"
        );
        aluno3 = alunoRepository.save(aluno3);

        Aluno aluno4 = new Aluno(
            "Ana Paula Ferreira",
            "789.123.456-00",
            "ana.ferreira@email.com",
            "(11) 66666-4444",
            LocalDate.of(1990, 4, 30),
            "Rua Oscar Freire, 200 - São Paulo/SP"
        );
        aluno4 = alunoRepository.save(aluno4);

        Aluno aluno5 = new Aluno(
            "Carlos Eduardo Souza",
            "321.654.987-00",
            "carlos.souza@email.com",
            "(11) 55555-5555",
            LocalDate.of(1993, 9, 12),
            "Av. Brigadeiro Faria Lima, 1500 - São Paulo/SP"
        );
        aluno5 = alunoRepository.save(aluno5);

        // Criar matrículas
        Matricula matricula1 = new Matricula(
            aluno1, cursoJava,
            LocalDate.now().minusMonths(2),
            LocalDate.now().plusMonths(4)
        );
        matriculaRepository.save(matricula1);

        Matricula matricula2 = new Matricula(
            aluno2, cursoPython,
            LocalDate.now().minusMonths(1),
            LocalDate.now().plusMonths(3)
        );
        matriculaRepository.save(matricula2);

        Matricula matricula3 = new Matricula(
            aluno3, cursoJavaScript,
            LocalDate.now().minusDays(15),
            LocalDate.now().plusMonths(7)
        );
        matriculaRepository.save(matricula3);

        Matricula matricula4 = new Matricula(
            aluno4, cursoDevOps,
            LocalDate.now().minusDays(5),
            LocalDate.now().plusMonths(4)
        );
        matriculaRepository.save(matricula4);

        Matricula matricula5 = new Matricula(
            aluno5, cursoJava,
            LocalDate.now().minusMonths(3),
            LocalDate.now().plusMonths(3)
        );
        matriculaRepository.save(matricula5);

        // Criar pagamentos
        Pagamento pagamento1 = new Pagamento(
            aluno1,
            new BigDecimal("2999.90"),
            LocalDate.now().plusDays(15),
            FormaPagamento.PIX
        );
        pagamentoRepository.save(pagamento1);

        Pagamento pagamento2 = new Pagamento(
            aluno2,
            new BigDecimal("2499.90"),
            LocalDate.now().plusDays(10),
            FormaPagamento.CARTAO_CREDITO
        );
        pagamentoRepository.save(pagamento2);

        Pagamento pagamento3 = new Pagamento(
            aluno3,
            new BigDecimal("3499.90"),
            LocalDate.now().plusDays(20),
            FormaPagamento.BOLETO
        );
        pagamentoRepository.save(pagamento3);

        Pagamento pagamento4 = new Pagamento(
            aluno4,
            new BigDecimal("3999.90"),
            LocalDate.now().plusDays(25),
            FormaPagamento.TRANSFERENCIA
        );
        pagamentoRepository.save(pagamento4);

        Pagamento pagamento5 = new Pagamento(
            aluno5,
            new BigDecimal("2999.90"),
            LocalDate.now().minusDays(5),
            FormaPagamento.CARTAO_DEBITO
        );
        pagamento5.realizarPagamento();
        pagamentoRepository.save(pagamento5);

        System.out.println("✅ Dados iniciais carregados com sucesso!");
        System.out.println("📊 Estatísticas:");
        System.out.println("   - Alunos: " + alunoRepository.count());
        System.out.println("   - Cursos: " + cursoRepository.count());
        System.out.println("   - Matrículas: " + matriculaRepository.count());
        System.out.println("   - Pagamentos: " + pagamentoRepository.count());
    }
}
