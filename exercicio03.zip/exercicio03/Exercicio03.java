import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Exercicio03 {
	public static void main(String[] args) {
		List<Produto> produtos = new ArrayList<>(Arrays.asList(
			new Produto("Smartphone", 2500.00, "Eletrônicos"),
			new Produto("Notebook", 4500.00, "Eletrônicos"),
			new Produto("Livro Java", 120.00, "Livros"),
			new Produto("Headset", 350.00, "Eletrônicos"),
			new Produto("Cafeteira", 280.00, "Casa"),
			new Produto("Livro POO", 98.90, "Livros"),
			new Produto("Batedeira", 399.90, "Casa"),
			new Produto("Câmera", 1999.00, "Eletrônicos")
		));

		double totalLivros = produtos.stream()
			.filter(p -> "Livros".equals(p.getCategoria()))
			.mapToDouble(Produto::getPreco)
			.sum();

		System.out.printf("Total do estoque (categoria Livros): %.2f\n", totalLivros);
	}
}
