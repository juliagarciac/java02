import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Exercicio02 {
	public static void main(String[] args) {
		List<Produto> produtos = new ArrayList<>(Arrays.asList(
			new Produto("Smartphone", 2500.00, "Eletrônicos"),
			new Produto("Notebook", 4500.00, "Eletrônicos"),
			new Produto("Livro Java", 120.00, "Livros"),
			new Produto("Headset", 350.00, "Eletrônicos"),
			new Produto("Cafeteira", 280.00, "Casa"),
			new Produto("Livro POO", 98.90, "Livros"),
			new Produto("Batedeira", 399.90, "Casa"),
			new Produto("Câmera", 1999.00, "Eletrônicos")
		));

		List<Double> precosMaioresQue500 = produtos.stream()
			.filter(p -> p.getPreco() > 500.0)
			.map(Produto::getPreco)
			.collect(Collectors.toList());

		System.out.println("Preços > 500.0:");
		precosMaioresQue500.forEach(System.out::println);
	}
}
